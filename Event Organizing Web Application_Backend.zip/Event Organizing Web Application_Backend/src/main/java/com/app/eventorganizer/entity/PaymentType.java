package com.app.eventorganizer.entity;

public enum PaymentType {
    INITIAL,
    REMAINING
}
