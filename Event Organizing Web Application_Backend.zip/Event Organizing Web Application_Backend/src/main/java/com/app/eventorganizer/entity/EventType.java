package com.app.eventorganizer.entity;

public enum EventType {
    BIRTHDAY,
    SEMINAR,
    WEDDING,
    CONCERT,
    CONFERENCE,
    WORKSHOP
}
