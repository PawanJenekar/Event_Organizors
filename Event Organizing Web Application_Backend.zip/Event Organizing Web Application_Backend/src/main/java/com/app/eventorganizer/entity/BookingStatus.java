package com.app.eventorganizer.entity;

public enum BookingStatus {
    CONFIRMED,
    CANCELED,
    PENDING
}
