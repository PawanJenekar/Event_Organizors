package com.app.eventorganizer.entity;

public enum PaymentStatus {
    COMPLETED,
    PENDING,
    FAILED
}
